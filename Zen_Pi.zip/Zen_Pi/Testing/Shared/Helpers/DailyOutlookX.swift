//
//  DailyOutlookX.swift
//  Zen Pi
//
//  Created by Christopher Huffaker on 12/20/24.
//

import Foundation
import Combine

@MainActor
final class DailyOutLookModel: ObservableObject {
    
    
    struct dailyOutlook: Decodable {
        
        let DOY: String
        let error: Bool
        let datex: String
        let entry: String       // The value of this is what I want to display
    }
    
    
        
        weak var delegate: Downloadable?
        
        
        let networkModel = Network()
        
        func downloaddailyoutlook(parameters: [String : Any], url: String) {
            
            let request = networkModel.request(parameters: parameters, url: url)
            
            networkModel.response(request: request) { (data) in
                let model = try? JSONDecoder().decode([dailyOutlook]?.self, from:data) as [dailyOutlook]?
                
                
            }
            
            
        }
    
    
    

    
    func buildIt() -> String {
        
        var goodValue = "Test"
        
        var paramX = ["doy": getDayOfYear()]
        
        goodValue = downloaddailyoutlook(parameters: paramX, url: URLServices.dailyoutlook)

        return goodValue
        
    }
}
   




    

