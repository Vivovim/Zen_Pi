//
//  AppDelegate.swift
//  Zen Pi
//
//  Created by Christopher Huffaker on 11/17/24.
//

import Foundation
import AppKit
import Combine

class AppDelegate: NSObject, NSApplicationDelegate {
    
    
    func applicationDidFinishLaunching(_ aNotification: Notification) {
        // Insert code here to initialize your application
    }
    
   


    
    
    
   
}
